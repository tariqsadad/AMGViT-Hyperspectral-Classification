# Reproducibility and release notes

These notes document the supplied notebooks, not independently rerun experiments.

## Notebook configurations

- **Indian Pines** (`Indian_Pines_original_executed.ipynb`): the training configuration in the uploaded source sets `SEEDS = [42, 52, 62, 72, 82]` and `EPOCHS = 600`. This differs from the paper's two-seed, 200-epoch description. Do not claim this notebook exactly reproduces the reported paper protocol without preparing and executing a separate corrected run.
- **Pavia University** (initial portion of the combined notebook): the source sets `SEEDS = [42, 52]` and `EPOCHS = 200`.
- **Salinas** (later portion of the combined notebook): includes additional data preparation, model training and evaluation cells with `SEEDS = [42, 52]` and `EPOCHS = 200`. The combined notebook also contains a second setup section with a five-seed list; execution order and state must be checked carefully.

## Prior to public release / submission

1. Separate the Pavia and Salinas workflows into self-contained notebooks and test each from a fresh Colab runtime.
2. Create a clearly labeled two-seed/200-epoch Indian Pines notebook and run it from scratch; retain the original notebook as historical material.
3. Verify the final Pavia prediction arrays against the saved model checkpoint, dataset labels and test indices, since differing prediction exports were observed during manuscript preparation.
4. Verify train/test split generation, preprocessing, seed controls and checkpoint loading for each dataset.
5. Confirm manuscript tables and figures are regenerated from the final outputs and that all reported metrics match.
6. Remove any personal Drive paths, private URLs, credentials or sensitive execution output if present. Check notebook output cells as well as code cells.
7. Add environment versions, dependency lockfile, dataset URLs, software license, author information and citation metadata.
8. Archive final checkpoints and results separately where size and permissions allow.

## Citation guidance

A GitHub repository link can be added once published. For a persistent scholarly citation, create a Zenodo release and cite its DOI. The repository and DOI must be real, publicly accessible and associated with the released code.

# AMGViT — Adaptive Multiscale Graph Vision Transformer for Hyperspectral Image Classification

Research code and original executed Google Colab notebooks for hyperspectral image classification on Indian Pines, Pavia University, and Salinas.

## Contents

| File | Description |
| --- | --- |
| `notebooks/Indian_Pines_original_executed.ipynb` | Original Indian Pines Colab notebook, including training, evaluation and saved outputs. |
| `notebooks/Pavia_University_and_Salinas_original_executed.ipynb` | Original combined Pavia University and Salinas Colab notebook, including training, evaluation and saved outputs. |
| `docs/REPRODUCIBILITY_NOTES.md` | Experiment configuration differences and release checklist. |
| `CITATION.cff` | Placeholder citation metadata; update authors and repository URL before publishing. |

## Running the notebooks

1. Open the selected `.ipynb` file in Google Colab.
2. Enable a GPU runtime.
3. Mount Google Drive and adjust the notebook's `ROOT`, `INPUT`, and `OUT` paths to your own folders.
4. Download the public hyperspectral datasets where prompted, and run the cells in order.
5. Save the resulting checkpoints, predictions and metrics separately; these files are **not included** in this source-code archive.

The notebooks are preserved as originally uploaded, including their execution outputs. They are **not** a harmonized, independently verified two-seed release. See `docs/REPRODUCIBILITY_NOTES.md` before citing the code as an exact reproduction of manuscript results.

## Recommended publication route

Upload the contents of this folder to a public GitHub repository, e.g. `AMGViT-Hyperspectral-Classification`. Then connect that repository to Zenodo, create a tagged release, and obtain the DOI assigned to the Zenodo record. Add the resulting real repository URL and DOI to the manuscript's Code Availability statement. Do not use placeholder links in a submitted manuscript.

## License

No license is assigned in this archive. Choose and add an appropriate `LICENSE` file before publishing. If third-party code or data is used, check its license and attribution requirements.
